#这里是事例
#开头写#是注释，空行自动跳过
#直接开始写指令，前面不加/ 像这样：
say hello world
title @a title helloworld

#这就可以执行了
#如果不懂指令要先学指令哦
#装载后输入/function test就可以执行我
#其他的道理是一样的，你可以新建一个
#好了开肝吧